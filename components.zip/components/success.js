import Alert from '@mui/material/Alert';

function success(){
    return(
        <Alert variant="filled" severity="success" onClose={() => {}}>  This is a success alert — check it out! </Alert>
    );

}
export default success;



